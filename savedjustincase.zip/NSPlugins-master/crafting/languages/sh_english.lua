LANGUAGE = {
	lc_cantFit = "%s can't fit in your inventory",
	lc_youCrafted = "You have crafted a %s",
	lc_youHaventRecipe = "You don't have enough resources to create a %s",
	lc_noRecipe = "%s doesn't have a recipe",
	lc_noTools = "You don't have the tools needed to craft this item!",
	lc_corrupt = "The item you tried to craft doesn't exist or is corrupt!"
}
