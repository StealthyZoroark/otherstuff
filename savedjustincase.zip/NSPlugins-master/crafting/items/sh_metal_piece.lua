ITEM.name = "Metal Piece"
ITEM.uniqueID = "metal_piece"
ITEM.model = "models/props/de_mirage/sheetmetal_shard_4.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Raw Materials"
ITEM.recipe = { ["iron_ore"] = 2}
ITEM.cant = 1
