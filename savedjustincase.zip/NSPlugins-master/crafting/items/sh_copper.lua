ITEM.name = "Copper"
ITEM.model = "models/items/crossbowrounds.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Raw Materials"
ITEM.recipe = { ["iron_copper"] = 1}
ITEM.cant = 1
ITEM.isBlueprint = false
