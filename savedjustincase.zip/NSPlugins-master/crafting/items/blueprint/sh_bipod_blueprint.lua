ITEM.name = "Bipod Blueprint"
ITEM.desc = ""
ITEM.model = "models/props_lab/clipboard.mdl"
ITEM.category = "Blueprints"
ITEM.recipe = { ["paper"] = 1, ["ink"] = 1, ["plastic"] = 2}
ITEM.isBlueprint = TRUE
ITEM.crafts = "bipod"
