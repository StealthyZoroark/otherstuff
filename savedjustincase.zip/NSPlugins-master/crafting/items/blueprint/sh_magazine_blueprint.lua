ITEM.name = "Magazine Blueprint"
ITEM.desc = ""
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.category = "Blueprints"
ITEM.recipe = { ["paper"] =1, ["ink"] = 1, ["metal_sheet"]= 2}
ITEM.isBlueprint = TRUE
ITEM.crafts = "magazine"
