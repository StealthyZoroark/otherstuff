ITEM.name = "Handguard Blueprint"
ITEM.desc = ""
ITEM.model = "models/props_lab/clipboard.mdl"
ITEM.category = "Blueprints"
ITEM.recipe = { ["paper"] =1, ["ink"] = 1, ["metal_piece"]= 3}
ITEM.isBlueprint = TRUE
ITEM.crafts = "handguard"
