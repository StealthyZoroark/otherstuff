ITEM.name = "Steel Piece"
ITEM.model = "models/props_junk/ibeam01b_cluster01.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Component"
ITEM.recipe = { ["coal"] = 2, ["iron_ore"] = 5}
ITEM.tools = {"hammer","welder"}
ITEM.cant = 1
ITEM.isBlueprint = false
