ITEM.name = "Metal Pot"
ITEM.model = "models/props_interiors/pot02a.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 0
ITEM.category = "misc"
ITEM.recipe = {["metal_piece"] = 1}
ITEM.cant = 1
