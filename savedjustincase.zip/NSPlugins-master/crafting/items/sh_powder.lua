ITEM.name = "Gunpowder"
ITEM.model = "models/props_junk/plasticbucket001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Component"
ITEM.recipe = { ["coal"] = 1, ["sulphur"] = 1, ["sand"] = 1}
ITEM.cant = 1
ITEM.isBlueprint = false
