ITEM.name = "Spring"
ITEM.model = "models/props_junk/cardboard_box004a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Component"
ITEM.recipe = { ["metal_piece"] = 3 }
ITEM.tools = {"hammer","welder"}
ITEM.cant = 1
ITEM.isBlueprint = false
