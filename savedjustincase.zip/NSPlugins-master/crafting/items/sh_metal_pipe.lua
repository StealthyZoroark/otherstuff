ITEM.name = "Metal Pipe"
ITEM.model = "models/props_lab/pipesystem02e.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.price = 0
ITEM.category = "Component"
ITEM.recipe = { ["metal_piece"] = 2}
ITEM.tools = {"hammer","welder"}
ITEM.cant = 1
ITEM.isBlueprint = false
