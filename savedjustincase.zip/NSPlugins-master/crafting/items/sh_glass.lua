ITEM.name = "Glass Shard"
ITEM.model = "models/props/cs_militia/skylight_glass_p6.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Raw Materials"
ITEM.recipe = { ["sand"] = 4}
ITEM.cant = 1
