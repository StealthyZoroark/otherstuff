ITEM.name = "Sheepdip"
ITEM.model = "models/healthvial.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Medicine"
ITEM.recipe = {["whisky"] = 1}
ITEM.cant = 1
ITEM.isBlueprint = false
