ITEM.name = "Ink"
ITEM.model = "models/props_junk/glassjug01.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Raw Materials"
