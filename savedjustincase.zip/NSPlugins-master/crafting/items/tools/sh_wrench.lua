ITEM.name = "Wrench"
ITEM.desc = "A wrench"
ITEM.model = "models/props_c17/tools_wrench01a.mdl"
ITEM.class = "hl2_m_wrench"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Tool"
ITEM.recipe = {["metal_piece"] = 4}
ITEM.tools = {"welder"}
ITEM.cant = 1
ITEM.isBlueprint = false
