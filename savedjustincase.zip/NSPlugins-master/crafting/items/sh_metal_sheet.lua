ITEM.name = "Metal Plate"
ITEM.model = "models/props_vents/vent_large_grill001.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Component"
ITEM.recipe = { ["metal_piece"] = 2}
ITEM.tools = {"hammer","welder"}
ITEM.cant = 1
ITEM.isBlueprint = false
