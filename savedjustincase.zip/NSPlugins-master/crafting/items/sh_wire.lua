ITEM.name = "Copper Cable"
ITEM.model = "models/props/cs_assault/wirespout.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Component"
ITEM.recipe = { ["copper"] = 2, ["plastic"] = 1 }
ITEM.cant = 3
