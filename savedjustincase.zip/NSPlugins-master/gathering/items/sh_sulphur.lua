ITEM.name = "Sulfur"
ITEM.desc = "A yellow colored brittle substance"
ITEM.model = "models/props_junk/garbage_coffeemug001a_chunk02.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Raw Material"
