ITEM.name = "Iron Ore"
ITEM.desc = "A grey colored mineral"
ITEM.model = "models/props_c17/canisterchunk01i.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Raw Material"
