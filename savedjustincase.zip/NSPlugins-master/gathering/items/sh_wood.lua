ITEM.name = "Wood Log"
ITEM.desc = "nil"
ITEM.model = "models/props_forest/log.mdl"
ITEM.width = 4
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Raw Material"
