ITEM.name = "Coal"
ITEM.desc = "A black colored mineral"
ITEM.model = "models/props_combine/breenbust_chunk03.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Raw Material"
