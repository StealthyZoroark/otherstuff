ITEM.name = "Plastic"
ITEM.desc = "nil"
ITEM.model = "models/props_c17/oildrumchunk01a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Raw Material"
