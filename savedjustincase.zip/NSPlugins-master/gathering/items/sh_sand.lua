ITEM.name = "Sand"
ITEM.desc = "nil"
ITEM.model = "models/props/de_prodigy/concretebags4.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Raw Material"
