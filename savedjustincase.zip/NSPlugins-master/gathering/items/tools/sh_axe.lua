ITEM.name = "Axe"
ITEM.desc = "An axe"
ITEM.model = "models/warz/melee/hatchet.mdl"
ITEM.class = "hl2_m_axe"
ITEM.width = 1
ITEM.height = 3
ITEM.price = 0
ITEM.category = "Tool"
ITEM.recipe = {["wood_plank"] = 2, ["metal_piece"] = 3}
ITEM.cant = 1
ITEM.isBlueprint = false
