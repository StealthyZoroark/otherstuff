ITEM.name = "Pickaxe"
ITEM.desc = "A pickaxe"
ITEM.model = "models/warz/melee/pickaxe.mdl"
ITEM.class = "hl2_m_pickaxe"
ITEM.width = 2
ITEM.height = 3
ITEM.price = 0
ITEM.category = "Tool"
ITEM.recipe = {["wood_plank"] = 2, ["metal_piece"] = 3}
ITEM.cant = 1
