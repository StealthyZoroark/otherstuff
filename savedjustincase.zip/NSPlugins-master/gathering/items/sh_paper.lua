ITEM.name = "Paper"
ITEM.desc = "A roll of paper"
ITEM.model = "models/props/cs_office/Paper_towels.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 0
ITEM.category = "Component"
