ITEM.name = "Magnetic Card - Level 1"
ITEM.uniqueID = "admkey"
ITEM.flag = "q"
ITEM.category = "Identification"
ITEM.model = Model("models/dorado/tarjeta1.mdl")
ITEM.desc = "A card that allows access to Level 1, 2 and 3 areas"
