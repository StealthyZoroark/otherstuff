ITEM.name = "Magnetic Card - Level 2"
ITEM.uniqueID = "comkey"
ITEM.flag = "q"
ITEM.category = "Identification"
ITEM.model = Model("models/dorado/tarjeta2.mdl")
ITEM.desc = "A card that allows access to Level 2 and Level 3 areas."
