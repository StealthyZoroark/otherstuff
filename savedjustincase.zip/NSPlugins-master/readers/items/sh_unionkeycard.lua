ITEM.name = "Magnetic Card - Level 3"
ITEM.uniqueID = "utckey"
ITEM.flag = "q"
ITEM.category = "Identification"
ITEM.model = Model("models/dorado/tarjeta3.mdl")
ITEM.desc = "A card that allows access to Level 3 areas."
