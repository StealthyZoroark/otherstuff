ITEM.name = "Magnetic Card - Level 0"
ITEM.uniqueID = "nuckey"
ITEM.flag = "q"
ITEM.category = "Identification"
ITEM.model = Model("models/dorado/tarjetazero.mdl")
ITEM.desc = "A card that allows access to any area"
