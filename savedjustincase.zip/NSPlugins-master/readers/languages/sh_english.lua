LANGUAGE = {
	validDoor = "Now look at a valid door",
	readerAdded = "You have added a reader",
	valuesRestored = "Reset selection"
}