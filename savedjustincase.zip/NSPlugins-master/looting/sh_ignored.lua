--Ignored Items will be set here
PLUGIN.ignored = {
	["cid"] = true,
	["cid2"] = true,
}
